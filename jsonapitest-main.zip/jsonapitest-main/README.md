# jsonapitest
Testing own json api
